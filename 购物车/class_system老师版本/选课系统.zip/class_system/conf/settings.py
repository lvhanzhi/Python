#  Author : Albert Ma


# import os
#
# BASE_DIR = os.path.dirname(os.path.dirname(__file__))
#
# BASE_DB = os.path.join(BASE_DIR, 'db')
import os
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
BASE_DB = os.path.join(BASE_DIR,'db')
