# 分析:
"""
1) 模块: random
2) 验证码包含数字,小写字母和大写字母
3) 一次产生一个随机数,该随机数可能是数字或小写字母或大写字母(三者中的随机)
4) 一共产生limt长度的验证码,所以要涉及字符串拼接
        -- 数字 -> str (转化后拼接)
        -- 字符(直接拼接)
5) 产生随机数的功能,函数
        -- 参数: 验证码长度 limt
        -- 返回值: 验证码 字符串类型
"""
import random
def make_code(limt):
    res = ""
    # 修饰res:字符串类型的验证码拼接
    for i in range(limt):
        n = str(random.randint(0, 9))
        l = chr(random.randint(97, 122))
        L = chr(random.randint(65, 90))
        res += random.choice([n, l, L])
    return res
print(make_code(6))