# 分析
"""
1) 模块:time, random
2) 进度值
    -- 已下载量 / 总量
3) 进度条
    -- 数字形式的进度值 转换 可视化的进度条
4) 刷新打印
    -- "\r"   end=""
5) 字符串的格式化
    -- %
6) 模拟下载过程

7) 功能:完成进度值 转换 可视化的进度条的函数
    -- 参数: 进度值precent
    -- 返回值: 功能就是打印,无需返回值
"""
# 刷新打印
# print("%d" %1, end="")
# print("\r%d" %2) # \r 与 end=""完成了覆盖打印,升级为循环打印就变成了刷新打印

# 字符串的格式化
# 需要被占位的情况下,前置%为转义字符
# 不需要被占位的情况下,所有%都是普通%
# print("%") # %
# print("%%") # %%
# print("%%d") # %%d
# # print("%%d" %10) # 报错
# # print("%d%" %10) # 报错
# print("%%%d" %10) # %10
# print("%d%%" %10) # 10%

# 打印结果分析
# [##########          ] 50%
# 已知量:宽度w  填充符'#'  进度值p
# 50% -> %d%%(p * 100)
# [%s]('#' * w * p)
# [%-50s] -> [%%-%d(50)s]

# print("%%%ds" %(10, "呵呵")) # %10s 报错
# print(("%%%ds" %10) %"呵呵") # 被转义成普通后的%在新的逻辑中会重新变为转义%(出现在前置位)
"""
w = 50
p = 0.75
ss = "%d" %w # 50
ss = (("%%-%ss" %ss) %('#' * int(w * p))) # %-50s == ##########
ss = "[%s] %d%%" %(ss, p * 100)
print(ss)
"""
import time
import random
def progress(p):
    w = 50
    ss = "%d" % w
    ss = (("%%-%ss" % ss) % ('#' * int(w * p)))
    ss = "[%s] %d%%" % (ss, p * 100)
    print("\r" + ss, end="")

curr_size = 0
total_size = 10241
while curr_size < total_size:
    time.sleep(0.1)
    # 剩余下载量
    last_size = total_size - curr_size
    # 本次网速下的该有下载量
    load_size = random.randint(900, 1024)
    if last_size > load_size:
        curr_size += load_size
    else: # 仅为最后一次下载量
        curr_size += last_size
    progress(curr_size / total_size)