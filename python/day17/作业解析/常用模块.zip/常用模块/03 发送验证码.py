# 发送功能 产生验证码功能 输出(验证码及剩余时间)展示功能
import random, time

# 发送功能
#   -- 参数: 不需要
#   -- 返回值: 不需要
def send_code():
    while True:
        tag = input("是否发送验证码[1:是 0:否]")
        if tag == "0":
            print("取消发送")
            break
        print("发送成功")
        code = "######" # 未获取验证码前的验证码占位
        curr_time = 0
        total_time = 5
        while curr_time < total_time:
            time.sleep(1)
            curr_time += 1
            if curr_time == 3:
                code = make_code()
            print_code(code, total_time - curr_time)
        print() # 打印换行
# 产生验证码功能
#   -- 参数: 位数固定,不需要参数
#   -- 返回值: 验证码
def make_code():
    limt = 6
    res = ""
    for i in range(limt):
        res += str(random.randint(0, 9))
    return res

# 输出(验证码及剩余时间)展示功能
#   -- 参数: 验证码 剩余时间
#   -- 返回值: 用于展示 -- 打印,不需要
def print_code(code, last_time):
    print("\r验证码为:%s,%ds后可以重新发送" %(code, last_time), end="")

send_code()